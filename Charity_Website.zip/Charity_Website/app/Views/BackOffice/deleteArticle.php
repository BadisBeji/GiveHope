<?php
// Affichage des erreurs
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

// Connexion à la base de données
require_once __DIR__ . '/../../../config/config.php';
require_once __DIR__ . '/../../Models/Article.php';

// Vérifier si l'ID est fourni
if (isset($_POST['id']) && is_numeric($_POST['id'])) {
    $articleId = (int) $_POST['id'];

    // Supprimer l'article
    $article = new Article($pdo);
    if ($article->deleteArticleById($articleId)) {
        // Redirection avec message de succès
        header("Location: articleList.php?message=deleted");
        exit;
    } else {
        echo "Erreur lors de la suppression de l'article.";
    }
} else {
    echo "ID invalide.";
}
?>
